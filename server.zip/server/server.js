const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());

const DB = {
  // 배열로 쌓인다.
  todo: [],
};

app.listen(3000, function () {
  // 서버 연결
  console.log("Node.js Start..");
});

app.get("/", function (req, res) {
  res.send("Hello Node.js @@@@");
});

app.get("/addTodo", function (req, res) {
  const todo = req.query.todo;

  DB.todo.push(todo); // push 배열에서 사용하는 javascript문법

  console.log(DB.todo);

  res.send({
    // 서버에 보내기
    code: "success",
    msg: "성공적으로 저장되었습니다.",
  });
  // 경로 설정 ( req 리퀘스트 요청, res 리스폰스 응답)
});
